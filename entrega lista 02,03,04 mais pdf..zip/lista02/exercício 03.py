'''3. Use a lista de stopwords (stopwords.txt) que serve para eliminar as palavras muito frequentes
 presentes no documento Corpus_en_NER.txt antes de gerar o word cloud, e refaça os itens (1) e (2) acima.
    As suas word clouds ficaram mais informativa em ambos os casos? Se sim, por que?'''

'''1. Um word cloud (ver exemplo na figura abaixo) contendo apenas os lemas dos 20 substantivos mais frequentes no documento.'''

from wordcloud import WordCloud
from nltk import WordNetLemmatizer, word_tokenize, pos_tag
import matplotlib.pyplot as plt

arq = open('Corpus_en_NER.txt', 'r',  encoding="utf8", errors='ignore')
texto = arq.read().replace('\n', '').lower()
arq.close()

arq = open('stopwords.txt', 'r')
listasStopWord = arq.read().lower().split('\n')
arq.close()

wordnet_lemmatizer = WordNetLemmatizer()
listaToken = word_tokenize(texto)


def removeCaracteresEspecias(listaToken):
    listaToken2= []
    punctuations = "?:!.,; ''``-_+={[]}@#$%¨&*()+§<>|\/?°ªº'"
    for word in listaToken:
        if word in punctuations:
            pass
        else:
            listaToken2.append(word)
    return listaToken2

def stopWord(listaStopWord, listaToken):
    lista = []
    for word in listaToken:
        if word not in listaStopWord:
            lista.append(word)
    return lista

def lematizer(listatoken):
    listaToken = removeCaracteresEspecias(listatoken)
    lista = []
    # print("{0:20}{1:20}".format("Word","Lemma"))
    # for word in listaToken:
    #     print ("{0:20}{1:20}".format(word,wordnet_lemmatizer.lemmatize(word)))
    for word in listaToken:
        lista.append(wordnet_lemmatizer.lemmatize(word))
    return lista

def posTag (listaToken):
    return pos_tag(listaToken)

listaToken = stopWord(listasStopWord, listaToken)
listaPOSTags = posTag(lematizer(listaToken))

'''wordCloud de Substantivos '''

dicTiposDePOS = {}
for pos in listaPOSTags:
    # if pos[0] == 'input':
    #     print(pos)
    if pos[1] in ['NN', 'NN$', 'NNS', 'NNS$', 'NP', 'NP$','NPS', 'NPS$', 'NR', 'NRS'] and pos[0] in dicTiposDePOS:
        dicTiposDePOS[pos[0]] += 1
    if pos[1] in ['NN', 'NN$', 'NNS', 'NNS$', 'NP', 'NP$','NPS', 'NPS$', 'NR', 'NRS'] and pos[0] not in dicTiposDePOS:
        dicTiposDePOS[pos[0]] = 1

listaPOSOrdenada = []


for item in sorted(dicTiposDePOS, key=dicTiposDePOS.get):
    listaPOSOrdenada.append((item, dicTiposDePOS[item]))

text = ''
listaSubstantivos = listaPOSOrdenada[len(listaPOSOrdenada)-20:]
for word in listaSubstantivos:
    text += word[0]+' '

# Create and generate a word cloud image:

wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="white").generate(text)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()


'''wordCloud de Verbos '''

dicTiposDePOS = {}
for pos in listaPOSTags:
    # if pos[0] == 'input':
    #     print(pos)
    if pos[1] in ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ'] and pos[0] in dicTiposDePOS:
        dicTiposDePOS[pos[0]] += 1
    if pos[1] in ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ'] and pos[0] not in dicTiposDePOS:
        dicTiposDePOS[pos[0]] = 1

listaPOSOrdenada = []

for item in sorted(dicTiposDePOS, key=dicTiposDePOS.get):
    listaPOSOrdenada.append((item, dicTiposDePOS[item]))

text = ''
listaVerbos = listaPOSOrdenada[len(listaPOSOrdenada)-20:]
for word in listaVerbos:
    text += word[0]+' '

# Create and generate a word cloud image:

wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="white").generate(text)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()


print('RESPOSTA ABAIXO: \n')

print('Resposta: No caso dos verbos realmente houve uma diminuição no número de palavras '
      'na segunda etapa, porém se formos olhar o contexto,\n'
      ' novas palavras que foram adicionadas não indicam o assunto abordado no texto,\n isso é '
      'evidenciado tanto para os verbo quanto para  lemma.')