'''2. Um word cloud contendo apenas os lemas dos 20 verbos mais frequentes'''

from nltk import WordNetLemmatizer, word_tokenize, pos_tag
import matplotlib.pyplot as plt
from wordcloud import WordCloud

arq = open('NLP.txt', 'r', encoding="utf8", errors='ignore')
texto = arq.read().replace('\n', '').lower()
arq.close()

wordnet_lemmatizer = WordNetLemmatizer()
listaToken = word_tokenize(texto)

def removeCaracteresEspecias(listaToken):
    listaToken2= []
    punctuations = "?:!.,; ''``-_+={[]}@#$%¨&*()+§<>|\/?°ªº'"
    for word in listaToken:
        if word in punctuations:
            pass
        else:
            listaToken2.append(word)
    return listaToken2

def lematizer(listatoken):
    listaToken = removeCaracteresEspecias(listatoken)
    lista = []
    # print("{0:20}{1:20}".format("Word","Lemma"))
    # for word in listaToken:
    #     print ("{0:20}{1:20}".format(word,wordnet_lemmatizer.lemmatize(word)))
    for word in listaToken:
        lista.append(wordnet_lemmatizer.lemmatize(word))
    return lista

def posTag (listaToken):
    return pos_tag(listaToken)

listaPOSTags = posTag(lematizer(listaToken))

dicTiposDePOS = {}
for pos in listaPOSTags:
    # if pos[0] == 'input':
    #     print(pos)
    if pos[1] in ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ'] and pos[0] in dicTiposDePOS:
        dicTiposDePOS[pos[0]] += 1
    if pos[1] in ['VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ'] and pos[0] not in dicTiposDePOS:
        dicTiposDePOS[pos[0]] = 1

listaPOSOrdenada = []

for item in sorted(dicTiposDePOS, key=dicTiposDePOS.get):
    listaPOSOrdenada.append((item, dicTiposDePOS[item]))


# Create and generate a word cloud image:
text = ''
lista = listaPOSOrdenada[len(listaPOSOrdenada)-20:]
for word in lista:
    text += word[0]+' '

# Create and generate a word cloud image:

wordcloud = WordCloud(max_font_size=50, max_words=100, background_color="white").generate(text)
plt.figure()
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis("off")
plt.show()
