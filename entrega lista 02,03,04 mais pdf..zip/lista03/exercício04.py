# -*- coding: utf-8 -*-

'''4. Usando o Brown Corpus disponível no NLTK (seção “news”), calcule a frequência de todos
os unigramas e exiba os 50 primeiros mais frequentes. Considere apenas o vocabulário,
isto é, word type.
a. Quais as classes gramaticais destas 50 palavras?
b. Gere um gráfico de barra para a distribuição acima e discuta seu resultado.
Link para acessar o Brown Corpus via NLTK:
https://www.nltk.org/book/ch02.html'''
import nltk
from nltk.corpus import brown
import numpy
import matplotlib.pyplot as plt

news_text = brown.words(categories='news')

def limpaCorpos(corpos):
    caracteresEspeciais = ["''", "--", "´", "``", '.', ',', '!', '?', ';', ':', '@', '*', '-', '&', '#', '%', '¨', " ", "[", "]"
        , "(", ")", "{", "}", "º", "+", "_", "*", "/", "|", "°", "-", "ª"]
    corpos2 =[]
    for word in corpos:
        word = word.lower()
        if word in caracteresEspeciais or  not word.isalpha()  :
            pass
        else:
            corpos2.append(word)
    return corpos2


def contaPalavra(corposLimpo):
    dic = {}
    corposOrdenado = []
    for i in corposLimpo:
        if i in dic:
            dic[i] += 1
        else:
            dic[i] = 1
    for item in sorted(dic, key=dic.get):
        corposOrdenado.append((item, dic[item]))
    return corposOrdenado

corposOk = contaPalavra(limpaCorpos(news_text))
corposCinquenta = corposOk[len(corposOk)-50:]

listaPalavasMaisFrequentes = []
frequenciaPalavras = []
for word in corposCinquenta:
    listaPalavasMaisFrequentes.append(word[0])
    frequenciaPalavras.append(word[1])
#Quais as classes gramaticais destas 50 palavras?
# Resposta da letra A.

for x in nltk.pos_tag(listaPalavasMaisFrequentes):
    print(x)

#b. Gere um gráfico de barra para a distribuição acima e discuta seu resultado.
# Resposta da letra B.

plt.barh(listaPalavasMaisFrequentes, frequenciaPalavras, color='green')
plt.ylabel('Palavra')
plt.xlabel('Frequência das 50 palavras.')
plt.title('Palavras ordenada pela frequência')
plt.show()


#Comentário:
''' Notamos que nesse corpos artigos epreposições são as que mais aparecem... Essa amostra segue a lei de Zipf'''