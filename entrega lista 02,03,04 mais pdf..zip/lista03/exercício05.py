# -*- coding: utf-8 -*-

'''5. Usando sentence splitting e tokenization para português implemente um programa que
receba como entrada o corpus de notícias NoticiasPortugues.zip e realize:

a.a divisão de sentenças
b.converta todas as palavras para minúscula
c.tokenize as frases
d.calcule a probabilidade de todos os unigrams presentes neste corpus, P(w i ). Considere
como unidade de unigrama, todos os tokens distintos (types ou vocabulário)
e. Implemente uma função que dada uma frase, contendo N tokens, seja retornada a
probabilidade desta frase usando o modelo de unigrama.

Ex.: P(“eu li uma má notícia ontem”) = P (Eu, li, uma, má, nóticia, ontem)
= P(eu) * P(li) * P(má) * P(notícia) * P(ontem)

OBS.: Para o cálculo das probabilides, use o artificio que transforma a multiplicação de
probabilidades numa soma de logarítimos.'''
import math
import nltk
from nltk.util import ngrams
import os

import zipfile
caminhoArquivoZip = '/home/ajts/PycharmProjects/lista03/Noticias_Portugues.zip'
caminhoParaExtrairZip = '/home/ajts/PycharmProjects/lista03/'
caminhosArquivosTxt = '/home/ajts/PycharmProjects/lista03'

def descompactaZip(caminhoAquivo, caminhoParaExtrair):
    fantasy_zip = zipfile.ZipFile(caminhoAquivo)
    fantasy_zip.extractall(caminhoParaExtrair)
    fantasy_zip.close()

def caminhosAaquivosTXT(caminhosArquivosTxt):
    caminhos = [os.path.join(caminhosArquivosTxt, nome) for nome in os.listdir(caminhosArquivosTxt)]
    arquivos = [arq for arq in caminhos if os.path.isfile(arq)]
    listaCaminhosTxt = [arq for arq in arquivos if arq.lower().endswith(".txt")]
    return listaCaminhosTxt

def concatenaArquivosTxt(listaCaminhos):
    textoLongo = ''
    for caminho in listaCaminhos:
        caminho = caminho.split('/')
        caminho = caminho[-1]
        if caminho[0:3] == "St-":
            arq = open(caminho, 'r', encoding = "ISO-8859-1", errors='ignore')
            text = arq.read()
            arq.close()
            textoLongo += text +" "
    return textoLongo

descompactaZip(caminhoArquivoZip, caminhoParaExtrairZip)
textolongo = concatenaArquivosTxt(caminhosAaquivosTXT(caminhosArquivosTxt))

#Resposta letra A logo abaixo...
sentencas = nltk.sent_tokenize(textolongo, 'portuguese')

#Resposta letra B logo abaixo...
sentencasEmMinusculas = []
for sentenca in sentencas:
    sentencasEmMinusculas.append(sentenca.lower())

#Resposta letra C logo abaixo...
tokens = []
for i in sentencasEmMinusculas:
    tokens += nltk.word_tokenize(i,'portuguese')

#Resposta letra D logo abaixo...

def limpaCorpos(corpos):
    caracteresEspeciais = ["''", "--", "´", "``", '.', ',', '!', '?', ';', ':', '@', '*', '-', '&', '#', '%', '¨', " ", "[", "]"
        , "(", ")", "{", "}", "º", "+", "_", "*", "/", "|", "°", "-", "ª", "$"]
    corpos2 =[]
    for word in corpos:
        word = word.lower()
        if word in caracteresEspeciais or word.isdigit():
            pass
        else:
            corpos2.append(word)
    return corpos2

corposLimpos = limpaCorpos(tokens)

def contaPalavra(corposLimpo):
    dic = {}
    corposOrdenado = []
    for i in corposLimpo:
        if i in dic:
            dic[i] += 1
        else:
            dic[i] = 1
    for item in sorted(dic, key=dic.get):
        corposOrdenado.append((item, dic[item]))
    return corposOrdenado

palavrasContadas = contaPalavra(corposLimpos)

print(palavrasContadas)

print(len(palavrasContadas))
probabilidadePalavras = []

for word in palavrasContadas:
    probabilidadePalavras.append((word, float(word[1]) / len(corposLimpos)))

# for i in probabilidadePalavras:
#     print(i)

#Resposta letra E logo abaixo...

def probabilidadeFrase(frase):
    tokens = nltk.word_tokenize(frase.lower(), 'portuguese')
    tokens = limpaCorpos(tokens)
    global probabilidadePalavras

    probabilidade = []
    for word in tokens:
        for i in probabilidadePalavras:
            if word == i[0][0]:
                probabilidade.append(math.exp(math.log10(i[1])))

    return math.fsum(probabilidade)

print('\n \n')
print("A probabilidade dessa frase aparecer no corpos Noticias_Portugues.zip "
      "é : ",probabilidadeFrase('Estados Unidos'))
print('\n \n')
