# -*- coding: utf-8 -*-
'''2. Baseando-se no corpus em português em anexo (Corpus_PT.txt) e fazendo apenas a
tokenização e remoção de números e símbolos do corpus:
Devenvolva um corretor autográfico para português que considere como palavras
candidatas sugeridas ao usuário
a. palavras com a distância de edição = 1
b. palavras com a distância de edição = 1 e 2
e as probabilidades de unigramas calculadas a partir do “Corpus_PT.txt”
Qual a relação do número de candidatos gerados nos casos (a) e (b)?
Comente seus resultados..'''

import nltk

arq = open('Corpus_PT.txt', 'r', encoding="utf8", errors='ignore')
text = arq.read().replace('\n', '').lower()
arq.close()

def limpaCorpos(corpos):
    caracteresEspeciais = ["''", "--", "´", "``", '.', ',', '!', '?', ';', ':', '@', '*', '-', '&', '#', '%', '¨', " ", "[", "]"
        , "(", ")", "{", "}", "º", "+", "_", "*", "/", "|", "°", "-", "ª", "$",'1','2','3','4', '5', '6', '7', '8', '9', '0']
    corpos2 =[]
    for word in corpos:
        word = word.lower()
        if word in caracteresEspeciais or  word.isdigit() :
            pass
        else:
            corpos2.append(word)
    return corpos2

text = nltk.word_tokenize(text,'portuguese')
text = limpaCorpos(text)



def levenshteinDistance(string1, string2):
    if len(string1) > len(string2):
        string1, string2 = string2, string1

    distances = range(len(string1) + 1)
    for i2, c2 in enumerate(string2):
        distances_ = [i2+1]

        for i1, c1 in enumerate(string1):
            if c1 == c2:
                distances_.append(distances[i1])
            else:
                distances_.append(1 + min((distances[i1], distances[i1 + 1], distances_[-1])))
        distances = distances_
    return distances[-1]

def minEditDistance(s, t):
    n, m = len(s), len(t)
    if n == 0:
        return m
    if m == 0:
        return n

    d = [[0 for i in range(m + 1)] for j in range(n + 1)]

    for i in range(1, n + 1):
        d[i][0] = i

    for i in range(1, m + 1):
        d[0][i] = i

    for i in range(1, n + 1):
        for j in range(1, m + 1):

            if s[i - 1] == t[j - 1]:
                cost = 0
            else:
                cost = 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)

    # printMatrix(d,s,t)
    #printMatrixSimple(d)
    return d[n][m]


palavraDistancia1 = []
palavraDistancia2e1 = []

for word in text:
    if minEditDistance('fundad', word) == 1:
        palavraDistancia1.append(word)
        palavraDistancia2e1.append(word)
    elif minEditDistance('fundad', word) == 2:
        palavraDistancia2e1.append(word)
    else:
        pass

#a. palavras com a distância de edição = 1
print(palavraDistancia1)

#b. palavras com a distância de edição = 1 e2

print(palavraDistancia2e1)

def calculaPropbabildadeUnigrama(listaTokens, listaCorpus):
    listaProbabilidade =[]
    uniqueWord = []
    totalPalavrasCorpus = len(listaCorpus)
    totalPalavrasUniqueWord = len(uniqueWord)
    for word in listaCorpus:
        if word in uniqueWord:
            pass
        else:
            uniqueWord.append(word)
    for word in listaTokens:
            contador = listaCorpus.count(word)
            probabilidade = (float(contador)+1)/(totalPalavrasCorpus + totalPalavrasUniqueWord)#Laplace smoothing
            listaProbabilidade.append((word, probabilidade))
    return listaProbabilidade

# for i in calculaPropbabildadeUnigrama(palavraDistancia2e1, text):
#     print('As probabilidades de unigramas calculadas a partir do “Corpus_PT.txt” é: ',i)


#Qual a relação do número de candidatos gerados nos casos (a) e (b)? Comente seus resultados.

print('Quantidade de palavras canditas para correção ortográfica de distância 1: ',len(palavraDistancia1))
print('Quantidade de palavras canditas para correção ortográfica de distância 2 e 1: ',len(palavraDistancia2e1))

print('A quantidade de palavras de distancia 1 é: %f%% em ralação ao total de palavras com distância 1 e 2.'%(len((palavraDistancia1)*100)/len(palavraDistancia2e1)))
print('Utilizando-se da técnica de distância de edição 1  existe uma maior probabilidade de se propor a palavra \ndesejada para o usuário em relação a correção ortográfica. ')