def printMatrix(matrix, s1, s2):  # Print with the name in row and columns
    print(' '.join('  ' + s2))
    count = 0
    s1 = ' ' + s1
    for i in matrix:
        print(s1[count] + ' ' + ' '.join(map(lambda j: str(j), i)) + '\n')
        count += 1


def printMatrixSimple(matrix):
    for i in matrix:
        print(' '.join(map(lambda j: str(j), i)) + '\n')


def minEditDistance(s, t):
    n, m = len(s), len(t)
    if n == 0:
        return m
    if m == 0:
        return n

    d = [[0 for i in range(m + 1)] for j in range(n + 1)]

    for i in range(1, n + 1):
        d[i][0] = i

    for i in range(1, m + 1):
        d[0][i] = i

    for i in range(1, n + 1):
        for j in range(1, m + 1):

            if s[i - 1] == t[j - 1]:
                cost = 0
            else:
                cost = 2
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)

    # printMatrix(d,s,t)
    #printMatrixSimple(d)
    for i in d:
        print(i)
    return d[n][m]


print('São  %d operações necessárias para tranformar "intension" em "extension".'
      '' %minEditDistance('intension', 'extension'))