'''3. Quebrando códigos : Decifre o significado das mensagens abaixo.
Use o corpus em inglês (em anexo) para coletar os unigramas e bi-gramas ( em nível de
caractere) mais frequentes.
Em seguida, faça as substituições dos unigramas e bigramas mais frequentes que você
encontrou no corpus, em cada uma das mensagens abaixo.
a. Forneça um histograma (uni-grama e bi-grama) listanto apenas os 30 mais frequentes
encontrados no corpus.
DICA: compare os n-gramas mais frequentes gerados dos corpus, com aqueles gerados
por cada mensagem de forma incremental. A cada iteração (substituição), verifique se a
mensagem começa a fazendo sentido.
Mensagem 1:

DSDRO XFIJV DIYSB ANQAL TAIMX VBDMB GASSA QRTRT CGGXJ MMTQC IPJSB AQPDR
SDIMS DUAMB CQCMS AQDRS DMRJN SBAGC IYTCY ASBCS MQXKS CICGX RSRCQ ACOGA
SJPAS AQHDI ASBAK GCDIS AWSJN CMDKB AQHAR RCYAE
Messagem 2:

An actual message from Baron August Schluga, a German spy in World War I
NKDIF SERLJ MIBFK FKDLV NQIBR HLCJU KFTFL KSTEN YQNDQ NTTEB TTENM QLJFS
NOSUM MLQTL CTENC QNKRE BTTBR HKLQT ELCBQ QBSFS KLTML SSFAI NLKBR RLUKT
LCJUK FTFLK FKSUC CFRFN KRYXB

Mensagem 3:
Here’s a 1992 message from the KGB to former CIA officer Aldrich Ames, who was
convicted of spying in 1994
CNLGV QVELH WTTAI LEHOT WEQVP CEBTQ FJNPP EDMFM LFCYF SQFSP NDHQF OEUTN
PPTPP CTDQN IFSQD TWHTN HHLFJ OLFSD HQFED HEGNQ TWVNQ HTNHH LFJWE BBITS
PTHDT XQQFO EUTYF SLFJE DEFDN IFSQG NLNGN PCTTQ EDOED FGQFI TLXNI

Mensagem 4:
This 1943 message from German U-Boat command was intercepted and decoded,
saving a convoy of Allied ships.
WLJIU JYBRK PWFPF IJQSK PWRSS WEPTM MJRBS BJIRA BASPP IHBGP RWMWQ SOPSV
PPIMJ BISUF WIFOT HWBIS WBIQW FBJRB GPILP PXLPM SAJQQ PMJQS RJASW LSBLW
GBHMJ QSWIL PXWOL'''

import nltk
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

arq = open('eng_news_2008_30K-sentences.txt', 'r', encoding="utf8", errors='ignore')
text = arq.read().replace('\n', '').lower()
arq.close()
def limpaCorpos(corpos):
    corpos2 =[]
    for word in corpos:
        if word.isalpha():
            corpos2.append(word)
    return corpos2

def makeUnigram(string):
    string = list(string)
    corpus = []
    for word in string:
        if word.isalpha():
            corpus.append(word)
    return corpus

def unigramaMaisFrequente(listaUnigrmas):
    uniqueCaractere = []
    for i in listaUnigrmas:
        if i in uniqueCaractere:
            pass
        else:
            uniqueCaractere.append(i)
    uniqueCaractereFrequencia = {}
    for x in uniqueCaractere:
        cont = listaUnigrmas.count(x)
        if cont > 5:  # Só pego os caracteres que aparecem com frequência maior que 5
            uniqueCaractereFrequencia[x] = cont
    return uniqueCaractereFrequencia

bigramas = nltk.bigrams(makeUnigram(text))

def bigramaMaisFrequente(listaBigrama):
    uniqueBigramas = []
    for i in listaBigrama:
        if i in uniqueBigramas:
            pass
        else:
            uniqueBigramas.append(i)
    uniqueBigrmaFrequencia = {}
    for x in uniqueBigramas:
        cont = listaBigrama.count(x)
        if cont > 5:  # Só pego os bigrmas que aparecem com frequência maior que 5
            uniqueBigrmaFrequencia[x] = cont
    return uniqueBigrmaFrequencia

def getListaUnigramaMaisFreq(dicUnigrama):
    listaUnigramaOrdenada = []
    dicUnigrma = unigramaMaisFrequente(makeUnigram(text))
    for item in sorted(dicUnigrma, key=dicUnigrma.get):
        listaUnigramaOrdenada.append((item, dicUnigrma[item]))
    trintaUnigramasMaisFreq = listaUnigramaOrdenada[len(listaUnigramaOrdenada)-30:]
    return trintaUnigramasMaisFreq

print(getListaUnigramaMaisFreq(unigramaMaisFrequente(makeUnigram(text))))

x = [i[1] for i in getListaUnigramaMaisFreq(unigramaMaisFrequente(makeUnigram(text)))]
histogram_example = plt.hist(x, bins=15, range=None, density=None, weights=None, cumulative=False, bottom=None, histtype='bar'
                         ,align='mid', orientation='vertical',
                         rwidth=0.8, log=False, color='red', label=None, stacked=False, normed=None,  data=None)
plt.xlabel('Frequência de cada unigrma')
plt.ylabel('Frequência')
plt.title('Histograma da frequência de unigrma')
plt.show()

def getListaBigramaMaisFreq(dicBigrama):
    listaBigramaOrdenada = []
    print(dicBigrama)
    for item in sorted(dicBigrama, key=dicBigrama.get):
        listaBigramaOrdenada.append((item, dicBigrama[item]))

    trintaBigramasMaisFreq = listaBigramaOrdenada[len(listaBigramaOrdenada)-30:]
    return trintaBigramasMaisFreq

x = [i[1] for i in getListaBigramaMaisFreq(bigramaMaisFrequente(list(bigramas)))]
histogram_example = plt.hist(x, bins=15, range=None, density=None, weights=None, cumulative=False, bottom=None, histtype='bar'
                         ,align='mid', orientation='vertical',
                         rwidth=0.8, log=False, color='red', label=None, stacked=False, normed=None,  data=None)

plt.xlabel('Frequência de cada bigrama')
plt.ylabel('Frequência')
plt.title('Histograma da frequência de bigrama')
plt.show()
